//
//  APViewController.m
//  AliSDKDemo
//
//  Created by 方彬 on 11/29/13.
//  Copyright (c) 2013 Alipay.com. All rights reserved.
//

#import "APViewController.h"
#import "Order.h"
#import "DataSigner.h"
#import <AlipaySDK/AlipaySDK.h>

#import "APAuthV2Info.h"

@implementation Product


@end

@interface APViewController ()

@end

@implementation APViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	[self generateData];
}


#pragma mark -
#pragma mark   ==============产生随机订单号==============


- (NSString *)generateTradeNO
{
	static int kNumber = 15;
	
	NSString *sourceStr = @"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	NSMutableString *resultStr = [[NSMutableString alloc] init];
	srand(time(0));
	for (int i = 0; i < kNumber; i++)
	{
		unsigned index = rand() % [sourceStr length];
		NSString *oneStr = [sourceStr substringWithRange:NSMakeRange(index, 1)];
		[resultStr appendString:oneStr];
	}
	return resultStr;
}



#pragma mark -
#pragma mark   ==============产生订单信息==============

- (void)generateData{
	NSArray *subjects = @[@"1",
                          @"2",@"3",@"4",
                          @"5",@"6",@"7",
                          @"8",@"9",@"10"];
	NSArray *body = @[@"I was testing data",
                      @"我是测试数据",
                      @"我是测试数据",
                      @"我是测试数据",
                      @"我是测试数据",
                      @"我是测试数据",
                      @"我是测试数据",
                      @"我是测试数据",
                      @"我是测试数据",
                      @"我是测试数据"];
	
	if (nil == self.productList) {
		self.productList = [[NSMutableArray alloc] init];
	}
	else {
		[self.productList removeAllObjects];
	}
    
    // creating Product with Subject,Body and Price
	for (int i = 0; i < [subjects count]; ++i) {
		Product *product = [[Product alloc] init];
		product.subject = [subjects objectAtIndex:i];
		product.body = [body objectAtIndex:i];
        
		product.price = 0.01f+pow(10,i-2);
		[self.productList addObject:product];
	}
}


#pragma mark -
#pragma mark UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 55.0f;
}

#pragma mark -
#pragma mark UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [self.productList count];
}




//
//用TableView呈现测试数据,外部商户不需要考虑
//
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
													reuseIdentifier:@"Cell"];
    
	Product *product = [self.productList objectAtIndex:indexPath.row];

    cell.textLabel.text = product.body;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Price：%.2f",product.price];
	
	return cell;
}


#pragma mark -
#pragma mark   ==============点击订单模拟支付行为==============
//
//选中商品调用支付宝极简支付
//
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

	/*
	 *Click for product instance and initialize the order information
	 */
	Product *product = [self.productList objectAtIndex:indexPath.row];
	
	/*
	 *The only business partner and sellerr。
	 *After the signing, Alipay will be assigned a unique parnter and seller for each business。
	 */
    
/*============================================================================*/
/*=======================Businesses need to fill out an application app===================================*/
/*============================================================================*/
	NSString *partner = @"2088101122136241";
    NSString *seller = @"abc@gmail.com";
    NSString *privateKey = @"MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAM68nDOVf+2StgB1AGd4Ug3NlHZ0l7D1IJMIhbgqwmiCTbG7TBfpNecthBq6Drbx4Y/p8jsmAGYlfzO+hBqZw7VjEd8sqD1Nt5sn/nygrUavzAMFn6yCRSXMOfOfZphEZOb/nqPo5SIbSmgBs3V+UD9JoXSWHH0sYaydlJpR1a8ZAgMBAAECgYBENbi30FCoGurP1cqvWOSBx11/g9J0wTvhJ0OvUvRXtP5bcLeXgAuX3c2jX9XxCHdqmz6fw1cIXMDOWsKNYERQobGxyrt5xZmnV0GlnNjlCBYi1rri9D9PNIJnd2sWVaMAMmGnxCXngpZvjyzKJM90xXxGtJsQNl3zqwuGGmuxfQJBAOg7PMtTSKbm9Jsb26qxSbL5A1M+xTZ6nAuvegB6+UvaTleKDVJZr6z1K1ofHiP3HW3pW8YXajoHAxbtlQtk35MCQQDj5WFXmMngIriPE19akIZby/GJ5D1v06MaIhOv3h2GGWpEEHFYGLqPypLuii3rmMXtXvH1I3q2bASkDw/oTyojAkEAyGZl/eduqGhg6IDPvKqkuIbd8bYXJP4FLqhMlaGJA4XtWOlOuaOfT5d5w5lavxp+ENzxTy3hgxWN+vkmRuDTdQJBAIDv63YbDMSSAGd6p21e7ZWMOpkwmA3n6JTFiOvsuDmBsZzWzLnyK8Nk8mKhrT9pjToyiKSQMUJ6tNl5aB+ggo8CQDPeZLhPA+YZFQRiuOrJXQBkyi0tNqtomx5xZ+VumCIMRGQJdMG/wy0tR8cD55bVV81VUSTIPDvR4Wc7IkxyoiE=";
/*============================================================================*/
/*============================================================================*/
/*============================================================================*/
	
	//partner和seller获取失败,提示
	if ([partner length] == 0 ||
        [seller length] == 0 ||
        [privateKey length] == 0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"prompt"
														message:@"lack partner or seller Or private key。"
													   delegate:self
											  cancelButtonTitle:@"determine"
											  otherButtonTitles:nil];
		[alert show];
		return;
	}
	
	/*
	 *Generates order information and signature
	 */
	//The product information given AlixPayOrder member variables
    Order *order = [[Order alloc] init];
	order.partner = partner;
	order.seller = seller;
	order.tradeNO = [self generateTradeNO]; //Order ID (self-developed by the merchant)
	order.productName = product.subject; //Commodity title
	order.productDescription = product.body; //product description
	order.amount = [NSString stringWithFormat:@"%.2f",product.price]; //Commodity price
	order.notifyURL =  @"http://www.xxx.com"; //Callback URL
    order.service = @"mobile.securitypay.pay";
    order.paymentType = @"1";
    order.inputCharset = @"utf-8";
    order.itBPay = @"30m";
    order.showUrl = @"m.alipay.com";
	
	// Application registration scheme, the definition of URL types in AlixPayDemo-Info.plist
	NSString *appScheme = @"alisdkdemo";
	
	//Spliced product information into strings
	NSString *orderSpec = [order description];
	NSLog(@"orderSpec = %@",orderSpec);
	
	//Get private and business information sign outside the business can store private keys and signatures depending on the circumstances, we only need to follow the RSA Signature specification, and the signature string base64 encoding and UrlEncode
	id<DataSigner> signer = CreateRSADataSigner(privateKey);
	NSString *signedString = [signer signString:orderSpec];
	
	//The successful string formatting string signature line, in strict accordance with the format
	NSString *orderString = nil;
	if (signedString != nil) {
		orderString = [NSString stringWithFormat:@"%@&sign=\"%@\"&sign_type=\"%@\"",
                       orderSpec, signedString, @"RSA"];
        
        [[AlipaySDK defaultService] payOrder:orderString fromScheme:appScheme callback:^(NSDictionary *resultDic) {
            NSLog(@"reslut = %@",resultDic);
        }];
        
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"oops!" message:@"something went wrong" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    }
}
@end
